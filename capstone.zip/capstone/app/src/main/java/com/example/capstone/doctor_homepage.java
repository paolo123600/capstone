package com.example.capstone;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class doctor_homepage extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.doctor_home);
    }
}
