package com.example.capstone;

import androidx.appcompat.app.AppCompatActivity;

public class Verification extends AppCompatActivity {

}
